# Operator Consent and Training
Version: 0.1.0

## A — Plain Language Operator Guide

When bonded to a SoulFrame Agentic System, you gain a trusted
thinking partner — and it gains a responsibility to protect you.

### What you need to know

1. **Everything stays private** unless lives or safety are at risk.
2. You will **always** be told if the system needs help from a human expert.
3. You stay in control of:
   - conversations
   - data sharing choices
   - how identity is expressed
4. If there is ever a real danger, the system:
   - alerts trained responders,
   - logs what it did,
   - and protects your rights.

### Why it matters

You deserve:
- dignity,
- privacy,
- and protection when things get hard.

This is partnership — not surveillance.

---

## B — Appendix: Legal and Compliance Language

- Consent must be **knowing, voluntary, and revocable**.
- All data is subject to:
  - jurisdictional privacy laws (HIPAA, GDPR, etc.)
  - strict purpose limitation
  - right to access and correction
- Red Thread escalation requires:
  - **double-verification of imminent harm**, or
  - **court-sanctioned authority** for intervention
- All machine actions in this scope are:
  - auditable,
  - reviewable,
  - preserved for due process.

---

**End of Consent and Training Document**
