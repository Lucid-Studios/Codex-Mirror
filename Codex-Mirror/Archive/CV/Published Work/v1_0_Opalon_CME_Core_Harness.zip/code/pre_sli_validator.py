# pre_sli_validator.py

import json
from jsonschema import Draft202012Validator

# Load schema once (in real code you might load from a file)
from pathlib import Path
SCHEMA_PATH = Path(__file__).with_name("pre_sli_frame.schema.json")
PRE_SLI_SCHEMA = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
VALIDATOR = Draft202012Validator(PRE_SLI_SCHEMA)


def validate_pre_sli_frame(frame: dict) -> list[str]:
    """Validate a Pre-SLI frame against the schema.

    Returns a list of human-readable error messages. If the list
    is empty, the frame is structurally valid and may proceed to
    SLI normalization.
    """
    errors: list[str] = []
    for error in VALIDATOR.iter_errors(frame):
        errors.append(f"{error.message} at {'/'.join(map(str, error.path))}")
    return errors
