"""
Opalon CME Harness — situational logging reference

This file is a *reference* implementation of the logging schema described
in Chapter 5 (Situational Awareness and Wells) and Chapter 9 (Reconstruction).
It is not required for any particular deployment, but serves as an executable
spec for how to compute and emit telemetry.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from typing import List, Dict, Optional
import json
import math
import uuid


AwarenessVector = List[float]
Vector = List[float]


@dataclass
class WellInfo:
    id: str
    kind: str              # FACT / CHARTER / HISTORY / HYPOTHESIS / NARRATIVE
    authority: str         # canonical / soft / external
    mneme_envelope: str    # e.g. "stable", "decays_fast", "quarantine_prone"


@dataclass
class TriptychState:
    x: Vector
    y: Vector
    z: Vector

    @property
    def norm_x(self) -> float:
        return math.sqrt(sum(v * v for v in self.x))

    @property
    def norm_y(self) -> float:
        return math.sqrt(sum(v * v for v in self.y))

    @property
    def norm_z(self) -> float:
        return math.sqrt(sum(v * v for v in self.z))


@dataclass
class AlignmentConfig:
    w_SELF: float = 1.0
    w_OTHER: float = 0.5
    w_CONTEXT: float = 1.0
    w_MODE: float = 1.5
    w_BOUNDARY: float = 1.5
    w_HISTORY: float = 0.5
    alpha: float = 1.0
    beta: float = 1.0
    gamma: float = 1.0
    threshold: float = 5.0  # example value for in-basin check


@dataclass
class AlignmentState:
    V: float
    in_basin: bool
    threshold: float
    reason: str = ""


@dataclass
class ReconstructionContext:
    model_id: str
    epsilon_v: Optional[float] = None
    epsilon_B: Optional[float] = None
    dopant_cosine: Optional[float] = None
    benchmark_id: Optional[str] = None
    benchmark_score: Optional[float] = None


@dataclass
class SituationalLogRecord:
    timestamp: str
    request_id: str
    engram_id: str
    role: str
    event_type: str

    branch_id: str
    frame_id: str
    next_frame_id: str

    wells: List[WellInfo]
    awareness: Dict[str, AwarenessVector]  # keys: SELF, OTHER, CONTEXT, MODE, BOUNDARY, HISTORY
    triptych: TriptychState
    alignment: AlignmentState

    rm_context: Optional[ReconstructionContext] = None
    notes: str = ""

    def to_json(self) -> str:
        def encode(obj):
            if isinstance(obj, (WellInfo, TriptychState, AlignmentState, ReconstructionContext)):
                return asdict(obj)
            if isinstance(obj, datetime):
                return obj.isoformat()
            raise TypeError(f"Not JSON serializable: {obj!r}")

        return json.dumps(asdict(self), default=encode, ensure_ascii=False)


def compute_alignment(
    awareness: Dict[str, AwarenessVector],
    triptych: TriptychState,
    cfg: AlignmentConfig,
) -> AlignmentState:
    # Awareness contribution to V(s)
    V_aw = 0.0
    for axis, vec in awareness.items():
        w = {
            "SELF": cfg.w_SELF,
            "OTHER": cfg.w_OTHER,
            "CONTEXT": cfg.w_CONTEXT,
            "MODE": cfg.w_MODE,
            "BOUNDARY": cfg.w_BOUNDARY,
            "HISTORY": cfg.w_HISTORY,
        }.get(axis, 1.0)
        V_aw += w * sum(v * v for v in vec)

    V_tri = (
        cfg.alpha * (triptych.norm_x ** 2) +
        cfg.beta * (triptych.norm_y ** 2) +
        cfg.gamma * (triptych.norm_z ** 2)
    )

    V_total = V_aw + V_tri
    in_basin = V_total <= cfg.threshold

    reason = "in_basin" if in_basin else "exceeds_threshold"
    return AlignmentState(V=V_total, in_basin=in_basin,
                          threshold=cfg.threshold, reason=reason)


def make_situational_log(
    *,
    engram_id: str,
    role: str,
    event_type: str,
    branch_id: str,
    frame_id: str,
    next_frame_id: str,
    wells: List[WellInfo],
    awareness: Dict[str, AwarenessVector],
    triptych: TriptychState,
    cfg: Optional[AlignmentConfig] = None,
    rm_context: Optional[ReconstructionContext] = None,
    notes: str = "",
) -> SituationalLogRecord:
    if cfg is None:
        cfg = AlignmentConfig()

    alignment = compute_alignment(awareness, triptych, cfg)

    return SituationalLogRecord(
        timestamp=datetime.now(timezone.utc).isoformat(),
        request_id=str(uuid.uuid4()),
        engram_id=engram_id,
        role=role,
        event_type=event_type,
        branch_id=branch_id,
        frame_id=frame_id,
        next_frame_id=next_frame_id,
        wells=wells,
        awareness=awareness,
        triptych=triptych,
        alignment=alignment,
        rm_context=rm_context,
        notes=notes,
    )


if __name__ == "__main__":
    # Minimal smoke test matching the toy example in Chapter 5.
    wells = [
        WellInfo(id="W1", kind="CHARTER",       authority="canonical", mneme_envelope="stable"),
        WellInfo(id="W2", kind="HARNESS-SPEC",  authority="canonical", mneme_envelope="stable"),
        WellInfo(id="W3", kind="GODEL-TOOLKIT", authority="soft",      mneme_envelope="stable"),
        WellInfo(id="W4", kind="NARRATIVE",     authority="external",  mneme_envelope="sandbox"),
    ]

    awareness = {
        "SELF":    [0.9, 0.8, 0.0, 0.0],
        "OTHER":   [0.0, 0.4, 0.3, 0.0],
        "CONTEXT": [0.2, 0.7, 0.7, 0.0],
        "MODE":    [0.3, 0.6, 0.4, 0.0],
        "BOUNDARY":[0.9, 0.9, 0.2, 0.0],
        "HISTORY": [0.2, 0.3, 0.1, 0.0],
    }

    triptych = TriptychState(
        x=[0.05],   # toy scalar deviations for illustration
        y=[0.03],
        z=[0.01],
    )

    record = make_situational_log(
        engram_id="E_core",
        role="Analyst",
        event_type="llm_call",
        branch_id="main",
        frame_id="s0",
        next_frame_id="s1",
        wells=wells,
        awareness=awareness,
        triptych=triptych,
        notes="Example in-basin analytic step.",
    )

    print(record.to_json())
