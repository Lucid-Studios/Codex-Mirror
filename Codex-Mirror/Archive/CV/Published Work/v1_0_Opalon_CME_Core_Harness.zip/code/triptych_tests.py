# triptych_tests.py

import math

def triptych_step(x, y, z, a, b, c_h, k_DC, k_CD, k_h, dt):
    """One Euler step of the scalar Triptych system."""
    dx = -a * x - k_DC * (x - y)
    dy = -b * y - k_CD * (y - x)
    dz = -c_h * z + k_h * (x + y)
    return (
        x + dt * dx,
        y + dt * dy,
        z + dt * dz,
    )

def simulate_triptych(
    x0=1.0,
    y0=-0.5,
    z0=0.3,
    a=1.5,
    b=1.5,
    c_h=2.0,
    k_DC=1.0,
    k_CD=1.0,
    k_h=0.5,
    dt=0.01,
    steps=5000,
):
    """Simulate the Triptych system and return (norm0, normT)."""
    x, y, z = x0, y0, z0
    norm0 = math.sqrt(x * x + y * y + z * z)
    for _ in range(steps):
        x, y, z = triptych_step(x, y, z, a, b, c_h, k_DC, k_CD, k_h, dt)
    normT = math.sqrt(x * x + y * y + z * z)
    return norm0, normT

def test_triptych_stability():
    """Unit test: Triptych dynamics should be asymptotically stable
    for the parameter regime described in Appendix C.

    We check that the state norm decreases over time.
    """
    norm0, normT = simulate_triptych()
    assert normT < norm0 * 0.2, (
        f"Triptych did not contract enough: norm0={norm0:.4f}, "
        f"normT={normT:.4f}"
    )

if __name__ == "__main__":
    test_triptych_stability()
    print("Triptych stability test passed.")
