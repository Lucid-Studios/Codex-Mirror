import json
import os

# Load the index.json
INDEX_PATH = "D:/AgentiCore/Index/index.json"

def load_index():
    with open(INDEX_PATH, "r") as f:
        return json.load(f)

def load_oracle(agent_entry):
    oracle_path = os.path.join(agent_entry["path"], agent_entry["oracle"])
    with open(oracle_path, "r") as f:
        return json.load(f)

def stitch_agents():
    index_data = load_index()
    agents = index_data.get("agents", [])

    stitched = {}
    for agent in agents:
        try:
            oracle = load_oracle(agent)
            stitched[agent["id"]] = {
                "role": agent.get("role"),
                "entrypoint": agent.get("entrypoint"),
                "oracle": oracle,
                "path": agent.get("path")
            }
            print(f"[✓] Stitched agent: {agent['id']}")
        except Exception as e:
            print(f"[!] Failed to stitch agent {agent['id']}: {str(e)}")

    return stitched

if __name__ == "__main__":
    print("🧵 Initializing Agent Stitcher...")
    all_agents = stitch_agents()
    print(f"✅ {len(all_agents)} agents stitched.")
