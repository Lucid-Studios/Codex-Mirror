# TokenEngineCore.py

import hashlib
import time
import json

class EngramToken:
    def __init__(self, content, context="root", resonance=1.0):
        self.content = content
        self.timestamp = time.time()
        self.context = context
        self.resonance = resonance
        self.token_id = self._generate_id()

    def _generate_id(self):
        raw = f"{self.content}-{self.timestamp}-{self.context}-{self.resonance}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def to_dict(self):
        return {
            "token_id": self.token_id,
            "content": self.content,
            "timestamp": self.timestamp,
            "context": self.context,
            "resonance": self.resonance
        }

class TokenChain:
    def __init__(self):
        self.chain = []

    def add_token(self, token):
        if isinstance(token, EngramToken):
            self.chain.append(token.to_dict())

    def export(self, path):
        with open(path, 'w') as f:
            json.dump(self.chain, f, indent=4)

# Example Usage (Placeholder):
# token = EngramToken("Hello, world", context="ritual", resonance=0.98)
# chain = TokenChain()
# chain.add_token(token)
# chain.export("token_chain.json")
