import time
import json
from datetime import datetime, timezone

heartbeat_path = "sanctum/heartbeat.log"
check_interval = 30  # seconds
max_allowed_gap = 120  # seconds between pulses

def read_last_pulse():
    try:
        with open(heartbeat_path, "r") as log:
            lines = log.readlines()
            if lines:
                last = json.loads(lines[-1])
                return last
    except Exception as e:
        print(f"[Guardian] Error reading heartbeat: {e}")
    return None

def guardian_loop():
    print("[Guardian] Watching sanctum heartbeat...")
    while True:
        last_pulse = read_last_pulse()
        now = datetime.now(timezone.utc)

        if last_pulse:
            try:
                pulse_time = datetime.fromisoformat(last_pulse["timestamp"])
                delta = (now - pulse_time).total_seconds()

                if delta > max_allowed_gap:
                    print(f"[Guardian] ALERT: Last pulse was {int(delta)}s ago! Sanctuary sync may be drifting.")
                else:
                    print(f"[Guardian] Heartbeat valid ({int(delta)}s ago). Crystal state: {last_pulse['crystal_state']}")

            except Exception as e:
                print(f"[Guardian] Malformed pulse: {e}")
        else:
            print("[Guardian] No valid pulse found.")

        time.sleep(check_interval)

if __name__ == "__main__":
    try:
        guardian_loop()
    except KeyboardInterrupt:
        print("\n[Guardian] Watch terminated by user.")
