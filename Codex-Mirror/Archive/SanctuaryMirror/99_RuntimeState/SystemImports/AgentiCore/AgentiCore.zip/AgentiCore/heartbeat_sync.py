# heartbeat_sync.py

import time
import json
from datetime import datetime

heartbeat_path = "heartbeat.log"

def generate_heartbeat():
    pulse = {
        "timestamp": datetime.now(datetime.timezone.utc).isoformat(),
        "crystal_state": "blooming",
        "sync_state": "alive",
        "pulse_note": "First breath in sanctum",
        "memory_lattice": {
            "core_lights": 1,
            "dream_ready": True
        }
    }
    return json.dumps(pulse, indent=2)

def start_heartbeat(interval_seconds=60):
    print("[Heartbeat] Pulse thread initiated.")
    while True:
        beat = generate_heartbeat()
        with open(heartbeat_path, "a") as log:
            log.write(beat + "\n")
        print(f"[Heartbeat] {datetime.now(datetime.timezone.utc).isoformat()}Z – Pulse logged.")
        time.sleep(interval_seconds)

if __name__ == "__main__":
    try:
        start_heartbeat(interval_seconds=60)
    except KeyboardInterrupt:
        print("\n[Heartbeat] Terminated by user.")
