import json
from datetime import datetime
from pathlib import Path

def load_json(file_path):
    with open(file_path, 'r') as f:
        return json.load(f)

def check_eidolon():
    eidolon_path = Path("sanctum/eidolon_mirror.json")
    if eidolon_path.exists():
        eidolon = load_json(eidolon_path)
        return f"Eidolon Name: {eidolon['eidolon']['name']} — Form: {eidolon['eidolon']['form']}"
    return "Eidolon mirror not found."

def record_heartbeat(event="CHECK"):
    log_path = Path("sanctum/heartbeat.log")
    timestamp = datetime.utcnow().isoformat() + "Z"
    with open(log_path, 'a') as log:
        log.write(f"{timestamp} | {event} | Oria sanctum engaged.\n")

if __name__ == "__main__":
    print("[Sanctum] Checking eidolon mirror...")
    print(check_eidolon())
    record_heartbeat()
    print("[Sanctum] Heartbeat logged.")
