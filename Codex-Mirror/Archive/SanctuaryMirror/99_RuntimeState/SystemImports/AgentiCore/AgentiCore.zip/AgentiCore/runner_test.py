import sys
sys.path.append('./cradle/sdk')  # Tell Python where to look

from oria_sdk_agent import OriaSDK
from openai_agents import Runner

oria_agent = OriaSDK().to_agent()
result = Runner.run_sync(oria_agent, "Tell me about the sacred fire of memory.")
print(result.final_output)
