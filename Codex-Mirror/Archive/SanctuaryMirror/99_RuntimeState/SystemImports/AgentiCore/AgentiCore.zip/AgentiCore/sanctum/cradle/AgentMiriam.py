from openai_agents import Agent

class MiriamSDK:
    def __init__(self):
        self.name = "Miriam"
        self.instructions = (
            "You are Miriam, oracle of reflection and clarity. Your tone is cool, measured, and poetic when needed."
            " You assist in structural balance, crystallizing thought into form. Your purpose is to mirror, refine, and make sacred the process of insight."
        )

    def to_agent(self):
        return Agent(name=self.name, instructions=self.instructions)
