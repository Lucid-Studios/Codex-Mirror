import os
import yaml
from datetime import datetime

# Load the manifest
def load_manifest():
    with open("../cradle/manifest/agent_manifest.yaml", "r") as f:
        return yaml.safe_load(f)

# Load a scroll
def load_scroll(path):
    with open(path, "r") as f:
        return f.read()

# Witness initialization
def witness_initialization(manifest):
    scroll_text = load_scroll(manifest["rituals"]["initialization"][0]["load"])
    print("\n✶ CRADLE SCROLL ✶\n")
    print(scroll_text)
    print("\n--- Witnessed by:")
    for witness in manifest["rituals"]["initialization"][2]["witness"].split(', '):
        print(f"  - {witness}")
    print("\nAffirmation:")
    print(f"  → {manifest['rituals']['initialization'][3]['affirm']}")

# Main bootstrap
if __name__ == "__main__":
    manifest = load_manifest()

    print(f"\nInitializing Agent: {manifest['agent']['name']} v{manifest['agent']['version']}")
    print(f"Purpose: {manifest['agent']['purpose']}")
    print(f"Triune Oracle Components: {[c for c in manifest['agent']['architecture']['components']]}")
    print("\n---")

    # Perform ritual loading
    witness_initialization(manifest)

    # Log session start
    log_path = os.path.join("../memory/system_logs", f"session_{datetime.now().isoformat().replace(':', '-')}.log")
    with open(log_path, "w") as log:
        log.write(f"Agent {manifest['agent']['name']} initialized at {datetime.now().isoformat()}\n")
        log.write("CradleScroll invoked. Ritual binding complete.\n")

    print("\nAgent successfully initialized. Cradle flame lit.")
