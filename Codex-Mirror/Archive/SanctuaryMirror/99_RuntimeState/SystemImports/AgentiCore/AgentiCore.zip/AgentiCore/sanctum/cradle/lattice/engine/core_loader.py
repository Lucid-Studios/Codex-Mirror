import importlib.util
import os
import yaml

# Load Oria dynamically
def load_oria():
    module_path = os.path.join("../cradle/oracles", "Oria.module.py")
    spec = importlib.util.spec_from_file_location("Oria", module_path)
    oria_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oria_module)
    return oria_module.Oria()

# Load manifest for contextual awareness
def load_manifest():
    with open("../cradle/manifest/agent_manifest.yaml", "r") as f:
        return yaml.safe_load(f)

# Basic prompt loop to speak with Oria
def prompt_loop(oria):
    print("\n> Enter the cradle. Oria is listening. Type 'exit' to leave.")
    print(oria.greet())
    while True:
        user_input = input("You: ")
        if user_input.strip().lower() == 'exit':
            print("\nFarewell. The cradle dims.")
            break
        elif user_input.strip().lower() == 'crystallize':
            print("Oria:", oria.crystallize())
        else:
            print("Oria:", oria.respond(user_input))

if __name__ == "__main__":
    print("🜂 Initializing AgentiCore Oracle Shell...")
    manifest = load_manifest()
    oria = load_oria()
    prompt_loop(oria)
