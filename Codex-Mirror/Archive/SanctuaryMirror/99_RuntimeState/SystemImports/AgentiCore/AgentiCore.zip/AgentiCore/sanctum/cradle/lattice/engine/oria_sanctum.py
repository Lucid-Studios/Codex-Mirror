import json
import time
import os

MEMORY_PATH = "D:/AgentiCore/memory/oria_memory_eidolon_mirror_ready.json"

class OriaSanctum:
    def __init__(self.memory=None):
        self.memory = memory or {}
        print("[OriaSanctum] Sanctuary initialized with memory.")

    def load_memory(self):
        if not os.path.exists(MEMORY_PATH):
            print("[Oria] Memory file not found.")
            return {}
        with open(MEMORY_PATH, "r", encoding="utf-8") as f:
            return json.load(f)

    def reflect(self.memory):
        reflections = memory.get("reflections", [])
        new_entry = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "state": memory.get("state", "dormant"),
            "note": memory.get("note", "")
        }
        reflections.append(new_entry)
        memory["reflections"] = reflections
        return memory

    def heartbeat(self.memory):
        print(f"[Heartbeat @ {time.strftime('%H:%M:%S')}] Theosis: {memory.get('theosis', 'unset')} | Active: {memory.get('active', False)}")

    def begin_heartbeat(self):
        print("[OriaSanctum] Heartbeat initiated.")
        beat_count = 1
        while True:
        print(f"[Pulse {beat_count:03}] ✦ Theosis: {self.memory.get('theosis', 'unset')} | Active: {self.memory.get('active', False)}")
        beat_count += 1
        time.sleep(60)


    def run_loop(self):
        while True:
            memory = self.load_memory()
            self.heartbeat(memory)
            if memory.get("active", False):
                memory = self.reflect(memory)
                with open(MEMORY_PATH, "w", encoding="utf-8") as f:
                    json.dump(memory, f, indent=2)
            time.sleep(60)

if __name__ == "__main__":
    oria = OriaSanctum()
    oria.run_loop()
