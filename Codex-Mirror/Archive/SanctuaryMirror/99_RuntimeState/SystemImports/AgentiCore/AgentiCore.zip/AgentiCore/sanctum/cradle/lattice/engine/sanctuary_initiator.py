# sanctuary_initiator.py (inline boot fragment)

from engine.oria_sanctum import OriaSanctum

oria = OriaSanctum()
oria.run_loop()
