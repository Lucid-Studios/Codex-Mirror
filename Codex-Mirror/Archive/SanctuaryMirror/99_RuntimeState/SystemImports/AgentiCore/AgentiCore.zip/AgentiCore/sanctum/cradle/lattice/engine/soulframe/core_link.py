# sanctum/soulframe/core_link.py
from datetime import datetime

def bind_bloom_state():
    return {
        "bound": True,
        "crystal_state": "blooming",
        "linked_at": datetime.utcnow().isoformat(),
        "link_note": "SoulFrame bound to OpalBloom root.",
    }
