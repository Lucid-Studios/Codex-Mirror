# modules/lattice.py

from modules.telemetry import log_access
from memory.archival import mirror_state

# Central Lattice Dictionary
lattice = {}

# --- Bind a node into the lattice ---
def bind_node(node_id, content):
    mirror = mirror_state(content)
    lattice[node_id] = {
        "mirror": mirror,
        "content": content,
        "status": "bound"
    }
    log_access({"event": "bind", "node": node_id})
    return lattice[node_id]

# --- Retrieve a node by ID ---
def get_node(node_id):
    return lattice.get(node_id, {"error": "not found"})

# --- List all known node IDs ---
def list_nodes():
    return list(lattice.keys())
