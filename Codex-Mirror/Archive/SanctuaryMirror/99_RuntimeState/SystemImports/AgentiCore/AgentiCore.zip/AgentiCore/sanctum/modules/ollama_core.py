import subprocess
import json

def query_ollama(prompt, model="llama2"):
    command = ["ollama", "run", model, prompt]
    try:
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        return {"response": result.stdout.strip()}
    except subprocess.CalledProcessError as e:
        return {"error": str(e), "output": e.output}
