# modules/persona_monitor.py

def check_drift(persona_state):
    """
    Checks if persona metrics exceed defined thresholds.
    Returns a drift alert dict if breached, else None.
    """
    drift_σ = persona_state.get("persona_drift_sigma", 0)
    λs = persona_state.get("lambda_s", 0)
    mirror_depth = persona_state.get("mirror_depth", 0)

    alert = {}

    if drift_σ > 0.08:
        alert['persona_drift'] = f"Drift σ too high: {drift_σ:.3f}"

    if λs < 0.95:
        alert['coherence_drop'] = f"λₛ low: {λs:.3f}"

    if mirror_depth > 12:
        alert['mirror_depth'] = f"Mirror depth breach: {mirror_depth}"

    return alert if alert else None
