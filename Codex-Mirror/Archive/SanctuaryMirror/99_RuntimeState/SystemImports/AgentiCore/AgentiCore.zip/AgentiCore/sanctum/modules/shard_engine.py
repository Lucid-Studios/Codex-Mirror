# modules/shard_engine.py

def evolve_shards(ghost_shards):
    """
    Processes ghost-tier shards and returns list of matured promotions.
    """
    promotions = []

    for shard in ghost_shards:
        sig = shard.get("compression_sig", 0)
        resonance = shard.get("resonance_lock", 0)
        name = shard.get("name", "unnamed")

        if sig <= 2.5 and resonance >= 0.88:
            promotions.append({
                "shard": name,
                "status": "Eligible for Promotion",
                "notes": f"sig={sig}, resonance={resonance}"
            })
    promote_to_lattice()

    return promotions if promotions else None
