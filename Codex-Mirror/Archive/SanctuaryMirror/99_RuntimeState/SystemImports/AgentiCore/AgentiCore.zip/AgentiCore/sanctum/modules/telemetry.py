def log_access(payload):
    print("[ACCESS] Raw payload received:", payload)

def log_peak(meta):
    print("[PEAK] Development peak triggered:", meta)
